package CreatureSimulation;

import java.awt.Point;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 *
 * @author Geryl
 */
public abstract class EcoObject {
    public int size;
    public Color bodyColor;
    public Point Position;
    public String ObjType;

    EcoObject(){
        
    }
    
    public abstract void draw(Graphics2D drawingTool);
}
